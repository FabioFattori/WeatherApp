import React, { useState, useEffect } from "react";
import Card from "react-bootstrap/Card";
import "../CSS/Home.css";
import Alert from "react-bootstrap/Alert";

function Home() {
  const [LocalitàSalvate, setLocalitàSalvate] = useState(null);

  function GraficaLocalita() {
    if (LocalitàSalvate === null) {
      return (
        <Alert key="dark" variant="dark">
          Non hai nessuna città nei preferiti :(
        </Alert>
      );
    } else if (Array.isArray(LocalitàSalvate)===false) {
      return (
        <Card style={{ width: "18rem" }}>
          <Card.Body>
            <Card.Title>{LocalitàSalvate.NomeCitta}</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">
              {LocalitàSalvate.descrizione}
            </Card.Subtitle>
            <Card.Text>
              Temperatura: {LocalitàSalvate.temp} °C <br />
              Percepita: {LocalitàSalvate.feels_like} °C <br />
              Umidità: {LocalitàSalvate.umidità}%
            </Card.Text>
          </Card.Body>
        </Card>
      );
    } else {
      return LocalitàSalvate.map((località) => {
        return (
          <Card className="LocandinaLocalità">
            <Card.Body>
              <Card.Title>{località.NomeCitta}</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                {località.descrizione}
              </Card.Subtitle>
              <Card.Text>
                Temperatura: {località.temp} °C <br />
                Percepita: {località.feels_like} °C <br />
                Umidità: {località.umidità}%
              </Card.Text>
            </Card.Body>
          </Card>
        );
      });
    }
  }

  useEffect(() => {
    setLocalitàSalvate(JSON.parse(localStorage.getItem("località")));
  }, []);

  return (
    <div className="HomeBody">
      <h1 className="Title">Le Tue Città Preferite:</h1>
      <div className="CittàSalvate">{GraficaLocalita()}</div>
    </div>
  );
}

export default Home;
