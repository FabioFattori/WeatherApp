import React from 'react';
import {Text,View} from 'react-native';

function Search({navigation}) {
  return (
    <View className="search">
      <Text onClick={navigation.goBack()}>Sium</Text>
    </View>
  );
}

export default Search;
