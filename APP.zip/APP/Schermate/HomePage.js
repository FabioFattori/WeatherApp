import React from 'react';
import {View, Text, StyleSheet, Button} from 'react-native';

class HomePage extends React.Component {
  render() {
    const navigation = this.props.navigation;

    return (
      <View>
        <Button
          title="sium"
          onPress={() => {
            navigation.navigate('Search');
          }}
        />
      </View>
    );
  }
}

export default HomePage;
