import React from 'react'
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import { useHistory } from 'react-router-dom';

function NavBar() {
const History=useHistory()  
  
    return (
    <Navbar bg="dark" variant="dark" sticky='top'>
    <Container>
    <Navbar.Brand>Meteo</Navbar.Brand>
    <Nav className="me-auto">
      <Nav.Link onClick={()=>History.push("/")}>Home</Nav.Link>
      <Nav.Link onClick={()=>History.push("/Search")}>Ricerca</Nav.Link>
    </Nav>
    </Container>
  </Navbar>
  )
}

export default NavBar