import React, { useState } from "react";
import Axios from "axios";
import InputGroup from "react-bootstrap/InputGroup";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Alert from "react-bootstrap/Alert";
import "../CSS/Search.css";

function Search() {
  let CittaCercata;
  const [typedValue, setValue] = useState("");
  let [WeatherData, setData] = useState("");
  const [grafica, setGrafica] = useState(null);
  const [allert, setAllert] = useState(null);

  function AddCity(Citta){
    let località=[]
    località.push(localStorage.getItem("località"))
    if(località===null){
      localStorage.setItem("località",Citta)
    }else{
      località.push(Citta)
      localStorage.setItem("località",località)
    }
  }

  function getWeatherData() {
    Axios.get(
      "https://api.openweathermap.org/data/2.5/weather?q=" +
        typedValue +
        "&units=metric&lang=it&appid=5d10ca667917b3430cb194283e34f3c0"
    )
      .catch((e) => {
        setAllert(
          <Alert key="danger" variant="danger" className="Alert">
            Nome non valido!
          </Alert>
        );
      })
      .then((response) => {
        setData((WeatherData = response.data));
        CittaCercata=typedValue.toUpperCase()
        CreazioneGrafica();
        setAllert(null);
      });
  }

  function CreazioneGrafica() {
    var urlIMG =
      "http://openweathermap.org/img/w/" + WeatherData.weather[0].icon + ".png";

    setGrafica(
      <div className="WeatherDataDisplay">
        <div className="CoppiaDivalori">
          <h3>Temperatura Effettiva:</h3>
          <h1>{WeatherData.main.temp} °C</h1>
        </div>
        <div className="CoppiaDivalori">
          <h3>Percepita:</h3>
          <h1>{WeatherData.main.feels_like} °C</h1>
        </div>
        <div className="CoppiaDivalori">
          <h3>Umidità:</h3>
          <h1>{WeatherData.main.humidity}%</h1>
        </div>
        <div className="CoppiaDivalori">
          <h2>
            {WeatherData.weather[0].description.toUpperCase()}
            <img src={urlIMG} alt="img" />
          </h2>
        </div>
        <Button variant="dark" onClick={()=>AddCity(CittaCercata)}>Aggiungi ai Preferiti</Button>
      </div>
    );
  }

  return (
    <div>
      <h1 className="title">Ricerca di una Località</h1>
      <div className="body">
        {allert}
        <InputGroup className="mb-3 input">
          <Form.Control
            value={typedValue}
            placeholder="Cerca"
            aria-label="Recipient's username"
            aria-describedby="basic-addon2"
            onChange={(e) => {
              setValue(e.target.value);
            }}
          />
          <Button
            variant="dark"
            id="button-addon2"
            onClick={() => getWeatherData()}
          >
            Invio
          </Button>
        </InputGroup>

        {grafica}
      </div>
    </div>
  );
}

export default Search;
