import React, { useState, useEffect } from "react";
import Card from "react-bootstrap/Card";
import "../CSS/Home.css";
import Alert from "react-bootstrap/Alert";

function Home() {
  const [LocalitàSalvate, setLocalitàSalvate] = useState(null);

  function GraficaLocalita () {
    if (LocalitàSalvate===null) {
      return (
        <Alert key="dark" variant="dark">
          Non hai nessuna città nei preferiti :(
        </Alert>
      );
    } else if(Array.isArray(LocalitàSalvate)){
       return <Card style={{ width: "18rem" }}>
        <Card.Body>
          <Card.Title>{LocalitàSalvate}</Card.Title>
          <Card.Subtitle className="mb-2 text-muted">
            Card Subtitle
          </Card.Subtitle>
          <Card.Text>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </Card.Text>
        </Card.Body>
      </Card>;
    }else{
        console.log(LocalitàSalvate)
        var localita=LocalitàSalvate.split(',')
        return localita.map((località)=>{
             return <Card className="LocandinaLocalità">
              <Card.Body>
                <Card.Title>{località}</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">
                  Card Subtitle
                </Card.Subtitle>
                <Card.Text>
                  Some quick example text to build on the card title and make up the
                  bulk of the card's content.
                </Card.Text>
              </Card.Body>
            </Card>;
          });
    }
  };

  useEffect(() => {
    setLocalitàSalvate(localStorage.getItem("località"));
  }, []);

  return (
    <div className="HomeBody">
      <h1 className="Title">Le Tue Città:</h1>
      <div className="CittàSalvate">{GraficaLocalita()}</div>
    </div>
  );
}

export default Home;
