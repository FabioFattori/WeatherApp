import React, { useState, useEffect } from "react";
import Axios from "axios";
import InputGroup from "react-bootstrap/InputGroup";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Alert from "react-bootstrap/Alert";
import "../CSS/Search.css";
import Toast from "react-bootstrap/Toast";
import { ToastContainer } from "react-bootstrap";
import { doc, getDoc, uodateDoc, updateDoc } from "firebase/firestore";
import { DB } from "../utils/firebase";
import { useHistory } from "react-router-dom";

function Search() {
  const History = useHistory();

  let CittaCercata = {
    NomeCitta: "",
    temp: "",
    feels_like: "",
    umidità: "",
    descrizione: "",
  };
  const [typedValue, setValue] = useState("");
  let [WeatherData, setData] = useState("");
  const [grafica, setGrafica] = useState(null);
  const [allert, setAllert] = useState(null);
  const [messaggioTogle, setMex] = useState("");
  const [show, setShow] = useState(false);
  const toggleShow = () => setShow(!show);

  useEffect(() => {
    if (localStorage.getItem("UserID") === null) {
      History.push("/Registrazione");
    }
  });

  function AddCity(docRef, totaleCitta) {
    updateDoc(docRef, { Preferiti: totaleCitta });
  }

  function controlloToAdd(Citta) {
    const docRef = doc(
      DB,
      "Users",
      localStorage.getItem("UserID").split("|")[1]
    );

    var cities=[];
    getDoc(docRef).then((response) => {
      
      response._document.data.value.mapValue.fields.Preferiti.arrayValue
       .values.forEach(element => {
          cities.push(element.stringValue)
        });
          console.log(cities)
       if (cities === undefined) {
         cities = [Citta.NomeCitta];
        AddCity(docRef, cities);
         setMex("Città aggiunta ai preferiti con Successo!");
      } else {
         var cittaGiaPresente = false;

        cities.forEach((città) => {
           if (città === Citta.NomeCitta) {
             cittaGiaPresente = true;
             setMex("Citta già presente nella sezione 'Preferiti'");
          }
         });

         if (!cittaGiaPresente) {
           setTimeout(() => {
             cities.push(Citta.NomeCitta);

            
             AddCity(docRef, cities);

             setMex("Città aggiunta ai preferiti con Successo!");
           }, 600);
         }
       }
    });
  }

  function getWeatherData() {
    Axios.get(
      "https://api.openweathermap.org/data/2.5/weather?q=" +
        typedValue +
        "&units=metric&lang=it&appid=0ec33f7b8a72aae2d8c7618d98f42a22"
    )
      .catch((e) => {
        setAllert(
          <Alert key="danger" variant="danger" className="Alert">
            Nome non valido!
          </Alert>
        );
      })
      .then((response) => {
        setData((WeatherData = response.data));

        CittaCercata.NomeCitta = typedValue.toUpperCase();
        CittaCercata.temp = WeatherData.main.temp;
        CittaCercata.feels_like = WeatherData.main.feels_like;
        CittaCercata.umidità = WeatherData.main.humidity;
        CittaCercata.descrizione =
          WeatherData.weather[0].description.toUpperCase();

        CreazioneGrafica();
        setAllert(null);
      });
  }

  function CreazioneGrafica() {
    var urlIMG =
      "http://openweathermap.org/img/w/" + WeatherData.weather[0].icon + ".png";

    setGrafica(
      <div className="WeatherDataDisplay">
        <div className="CoppiaDivalori">
          <h3>Temperatura Effettiva:</h3>
          <h1>{WeatherData.main.temp} °C</h1>
        </div>
        <div className="CoppiaDivalori">
          <h3>Percepita:</h3>
          <h1>{WeatherData.main.feels_like} °C</h1>
        </div>
        <div className="CoppiaDivalori">
          <h3>Umidità:</h3>
          <h1>{WeatherData.main.humidity}%</h1>
        </div>
        <div className="CoppiaDivalori">
          <h2>
            {WeatherData.weather[0].description.toUpperCase()}
            <img src={urlIMG} alt="img" />
          </h2>
        </div>
        <Button
          variant="dark"
          onClick={() => {
            controlloToAdd(CittaCercata);
            toggleShow();
          }}
        >
          Aggiungi ai Preferiti
        </Button>
      </div>
    );
  }

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      getWeatherData();
    }
  };

  return (
    <div>
      <ToastContainer position="top-end" className="p-3 TOAST">
        <Toast show={show} onClose={toggleShow}>
          <Toast.Header>
            <img
              src="holder.js/20x20?text=%20"
              className="rounded me-2"
              alt=""
            />
            <strong className="me-auto">Meteo</strong>
            <small>Adesso</small>
          </Toast.Header>
          <Toast.Body>{messaggioTogle}</Toast.Body>
        </Toast>
      </ToastContainer>

      <h1 className="title">Ricerca di una Località</h1>
      <div className="body">
        {allert}
        <InputGroup className="mb-3 input">
          <Form.Control
            value={typedValue}
            placeholder="Cerca"
            aria-label="Recipient's username"
            aria-describedby="basic-addon2"
            onKeyDown={handleKeyDown}
            onChange={(e) => {
              setValue(e.target.value);
            }}
          />
          <Button
            variant="dark"
            id="button-addon2"
            onClick={() => getWeatherData()}
          >
            Invio
          </Button>
        </InputGroup>

        {grafica}
      </div>
    </div>
  );
}

export default Search;
