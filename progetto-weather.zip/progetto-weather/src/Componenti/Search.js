import React, { useState, useEffect } from "react";
import Axios from "axios";
import InputGroup from "react-bootstrap/InputGroup";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Alert from "react-bootstrap/Alert";
import "../CSS/Search.css";
import Toast from "react-bootstrap/Toast";
import { ToastContainer } from "react-bootstrap";
import { doc, getDoc, uodateDoc, updateDoc } from "firebase/firestore";
import { DB } from "../utils/firebase";
import { useHistory } from "react-router-dom";
import { MapContainer } from "react-leaflet/MapContainer";
import { TileLayer } from "react-leaflet/TileLayer";
import { Marker } from "react-leaflet/Marker";
import { Popup } from "react-leaflet/Popup";

function Search() {
  const History = useHistory();

  let CittaCercata = {
    NomeCitta: "",
    x: 0,
    y: 0,
    temp: "",
    feels_like: "",
    umidità: "",
    descrizione: "",

    TomorrowTemp: {
      day: "",
      evening: "",
      night: "",
    },

    TomorrowFeelsLike: {
      day: "",
      evening: "",
      night: "",
    },
    TomorrowUmidity: "",
    TomorrowDescription: "",
    TomorrowIcon: "",
  };
  const [typedValue, setValue] = useState("");
  let [WeatherData, setData] = useState("");
  const [grafica, setGrafica] = useState(null);
  const [allert, setAllert] = useState(null);
  const [messaggioTogle, setMex] = useState("");
  const [show, setShow] = useState(false);
  const toggleShow = () => setShow(!show);

  useEffect(() => {
    if (localStorage.getItem("UserID") === null) {
      History.push("/Registrazione");
    }
  });

  function AddCity(docRef, totaleCitta) {
    updateDoc(docRef, { Preferiti: totaleCitta });
  }

  function controlloToAdd(Citta) {
    const docRef = doc(
      DB,
      "Users",
      localStorage.getItem("UserID").split("|")[1]
    );

    var cities = [];
    getDoc(docRef).then((response) => {
      if (
        response._document.data.value.mapValue.fields.Preferiti.arrayValue
          .values === undefined
      ) {
        cities = [Citta.NomeCitta];
        AddCity(docRef, cities);
        setMex("Città aggiunta ai preferiti con Successo!");
      } else {
        response._document.data.value.mapValue.fields.Preferiti.arrayValue.values.forEach(
          (element) => {
            cities.push(element.stringValue);
          }
        );

        var cittaGiaPresente = false;

        cities.forEach((città) => {
          if (città === Citta.NomeCitta) {
            cittaGiaPresente = true;
            setMex("Citta già presente nella sezione 'Preferiti'");
          }
        });

        if (!cittaGiaPresente) {
          setTimeout(() => {
            cities.push(Citta.NomeCitta);

            AddCity(docRef, cities);

            setMex("Città aggiunta ai preferiti con Successo!");
          }, 600);
        }
      }
    });
  }

  function getWeatherDataOfTomorrow() {
    Axios.get(
      "https://api.openweathermap.org/data/2.5/onecall?lat=" +
        CittaCercata.y +
        "&lon=" +
        CittaCercata.x +
        "&units=metric&lang=it&exclude=current,minutely,hourly&appid=0ec33f7b8a72aae2d8c7618d98f42a22"
    )
      .catch((e) => {
        return;
      })
      .then((response) => {
        //tomorrow data set
        CittaCercata.TomorrowTemp.day = response.data.daily[0].temp.day;

        CittaCercata.TomorrowTemp.evening = response.data.daily[0].temp.eve;

        CittaCercata.TomorrowTemp.night = response.data.daily[0].temp.night;

        CittaCercata.TomorrowFeelsLike.day =
          response.data.daily[0].feels_like.day;

        CittaCercata.TomorrowFeelsLike.evening =
          response.data.daily[0].feels_like.eve;

        CittaCercata.TomorrowFeelsLike.night =
          response.data.daily[0].feels_like.night;

        CittaCercata.TomorrowUmidity = response.data.daily[0].humidity;

        CittaCercata.TomorrowDescription =
          response.data.daily[0].weather[0].description;

        CittaCercata.TomorrowIcon = response.data.daily[0].weather[0].icon;
        CreazioneGrafica();
      });
  }

  function getWeatherData() {
    Axios.get(
      "https://api.openweathermap.org/data/2.5/weather?q=" +
        typedValue +
        "&units=metric&lang=it&appid=0ec33f7b8a72aae2d8c7618d98f42a22"
    )
      .catch((e) => {
        setAllert(
          <Alert key="danger" variant="danger" className="Alert">
            Nome non valido!
          </Alert>
        );
      })
      .then((response) => {
        setData((WeatherData = response.data));

        CittaCercata.x = WeatherData.coord.lon;
        CittaCercata.y = WeatherData.coord.lat;
        CittaCercata.NomeCitta = typedValue.toUpperCase();
        CittaCercata.temp = WeatherData.main.temp;
        CittaCercata.feels_like = WeatherData.main.feels_like;
        CittaCercata.umidità = WeatherData.main.humidity;
        CittaCercata.descrizione =
          WeatherData.weather[0].description.toUpperCase();

        setAllert(null);
      });
  }

  function CreazioneGrafica() {
    var urlIMG =
      "http://openweathermap.org/img/w/" + WeatherData.weather[0].icon + ".png";

    var urlIMGTomorrow =
      "http://openweathermap.org/img/w/" + CittaCercata.TomorrowIcon + ".png";

    setGrafica(
      <div className="WeatherDataDisplay">
        <div className="ValoriNumerici">
          <div className="CoppiaDivalori">
            <h1>Temperatura Attuale</h1>
            <br />
            <h3>Effettiva :</h3>
            <h1>{WeatherData.main.temp} °C</h1>
            <br />
            <h3>Percepita :</h3>
            <h1>{WeatherData.main.feels_like} °C</h1>
            <br />
            <h3>Umidità :</h3>
            <h1>{WeatherData.main.humidity}%</h1>
            <br />
            <h2>
              {WeatherData.weather[0].description.toUpperCase()}
              <img src={urlIMG} alt="img" />
            </h2>
          </div>

          <div className="CoppiaDivalori">
            <h1>Previsioni di Domani</h1>
            <br />
            <h3>Effettiva :</h3>
            <h4>Mattina : {CittaCercata.TomorrowTemp.day} °C</h4>
            <h4>Pomeriggio : {CittaCercata.TomorrowTemp.evening} °C</h4>
            <h4>Sera : {CittaCercata.TomorrowTemp.night} °C</h4>
            <br />
            <h3>Percepita</h3>
            <h4>Mattina : {CittaCercata.TomorrowFeelsLike.day} °C</h4>
            <h4>Pomeriggio : {CittaCercata.TomorrowFeelsLike.evening} °C</h4>
            <h4>Sera : {CittaCercata.TomorrowFeelsLike.night} °C</h4>
            <br />
            <h3>Umidità :</h3>
            <h3>{CittaCercata.TomorrowUmidity} %</h3>
            <br />
            <h2>
              {CittaCercata.TomorrowDescription.toUpperCase()}
              <img src={urlIMGTomorrow} alt="img" />
            </h2>
          </div>
        </div>

        <MapContainer
          className="cartina"
          center={[CittaCercata.y, CittaCercata.x]}
          zoom={13}
          scrollWheelZoom={true}
        >
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <Marker position={[CittaCercata.y, CittaCercata.x]}>
            <Popup>{CittaCercata.NomeCitta}</Popup>
          </Marker>
        </MapContainer>

        <Button
          variant="dark"
          onClick={() => {
            controlloToAdd(CittaCercata);
            toggleShow();
          }}
        >
          Aggiungi ai Preferiti
        </Button>
      </div>
    );
  }

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      getWeatherData();
      getWeatherDataOfTomorrow();
    }
  };

  return (
    <div>
      <ToastContainer position="top-end" className="p-3 TOAST">
        <Toast show={show} onClose={toggleShow}>
          <Toast.Header>
            <img
              src="holder.js/20x20?text=%20"
              className="rounded me-2"
              alt=""
            />
            <strong className="me-auto">Meteo</strong>
            <small>Adesso</small>
          </Toast.Header>
          <Toast.Body>{messaggioTogle}</Toast.Body>
        </Toast>
      </ToastContainer>

      <h1 className="title">Ricerca di una Località</h1>
      <div className="body">
        {allert}
        <InputGroup className="mb-3 input">
          <Form.Control
            value={typedValue}
            placeholder="Cerca"
            aria-label="Recipient's username"
            aria-describedby="basic-addon2"
            onKeyDown={handleKeyDown}
            onChange={(e) => {
              setValue(e.target.value);
            }}
          />
          <Button
            variant="dark"
            id="button-addon2"
            onClick={() => {
              getWeatherData();
              getWeatherDataOfTomorrow();
            }}
          >
            Invio
          </Button>
        </InputGroup>

        {grafica}
      </div>
    </div>
  );
}

export default Search;
