import React, { useState, useEffect } from "react";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import { useHistory } from "react-router-dom";
import "../CSS/NavBar.css";
import NavDropdown from "react-bootstrap/NavDropdown";

function NavBar() {
  const History = useHistory();

  //   React.useEffect(() => {
  //     function handleResize() {
  //       if(window.innerWidth>650){
  //         setExpand(true);
  //       }else{
  //         setExpand(false);
  //       }

  // }

  //     window.addEventListener('resize', handleResize)
  //   })

  const KnowWhatToShow = () => {
    if (localStorage.getItem("UserID") === null) {
      return (
        <Nav.Link onClick={() => History.push("/Registrazione")}>
          Registrati
        </Nav.Link>
      );
    } else {
      return (
        <div className="Nav">
          <Nav.Link>{localStorage.getItem("UserID").split("|")[0]}</Nav.Link>
          <Nav.Link
            onClick={() => {
              localStorage.clear();
              window.location.reload();
            }}
          >
            logOut
          </Nav.Link>
        </div>
      );
    }
  };

  return (
    <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Container>
        <Navbar.Brand>Meteo</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link onClick={() => History.push("/")}>Home</Nav.Link>
            <Nav.Link onClick={() => History.push("/Search")}>Ricerca</Nav.Link>
            {KnowWhatToShow()}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    // <Navbar bg="dark" variant="dark" sticky="top" className="Navbar" >
    //   <Container>
    //     <Navbar.Brand>Meteo</Navbar.Brand>
    //     <Nav className="me-auto">
    //       <Nav.Link onClick={() => History.push("/")}>Home</Nav.Link>
    //       <Nav.Link onClick={() => History.push("/Search")}>Ricerca</Nav.Link>
    //       {KnowWhatToShow()}
    //     </Nav>
    //   </Container>
    // </Navbar>
  );
}

export default NavBar;
