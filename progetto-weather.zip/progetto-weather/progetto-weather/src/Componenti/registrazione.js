import React, { useState } from "react";
import { DB } from "../utils/firebase";
import { useHistory } from "react-router-dom";
import { collection, addDoc, getDocs } from "firebase/firestore";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "../CSS/REG.css";
import Alert from "react-bootstrap/Alert";

function Registrazione() {
  const History = useHistory();

  const [AlertErrore, setAlertErrore] = useState(false); //si attiva quando c'è qualsiasi errore

  const [AlertLoginUser, setAlertLoginUser] = useState(false); //si attiva quando un utente già registrato si logga

  const [AlertNuovoUser, setAlertNuovoUser] = useState(false); //si attiva quando un utente nuovo si registra per la prima volta

  const [email, setEmail] = useState("");

  const [pass, setPass] = useState("");

  const PushData = (e) => {
    e.preventDefault();

    const collectionUtente = collection(DB, "Users");

    if (email === "" || pass === "") {
      setAlertErrore(true);
      return;
    }
    getDocs(collectionUtente).then((response) => {
      const Users = response.docs.map((doc) => ({
        data: doc.data(),
        id: doc.id,
      }));

      var controllo;
      Users.forEach((User) => {
        if (User.data.Email === email) {
          if (User.data.Pass === pass) {
            controllo = User.id;
          } else {
            controllo = "errore";
          }
        }
      });

      if (controllo !== undefined) {
        if (controllo !== "errore") {
          setAlertLoginUser(true);
          setTimeout(() => {
            localStorage.setItem("UserID", email + "|" + controllo);
            History.push("/");
            window.location.reload();
          }, 700);
        } else {
          setAlertErrore(true);
        }
      } else {
        console.log("new User detected");

        //codice che pusha i dati nel DB
        addDoc(collectionUtente, {
          Email: email,
          Pass: pass,
          Preferiti: [],
        }).then((response) => {
          setAlertNuovoUser(true);
          setTimeout(() => {
            localStorage.setItem("UserID", email + "|" + response.id);
            History.push("/");
            window.location.reload();
          }, 700);
        });
      }
    });
  };

  return (
    <div className="body">
      <Form onSubmit={(e) => PushData(e)}>
        <Alert
          variant="danger"
          show={AlertErrore}
          onClose={() => setAlertErrore(false)}
          dismissible
        >
          <Alert.Heading>
            ERRORE! Controlla l'email inserita e/o la password!
          </Alert.Heading>
        </Alert>
        <Alert show={AlertNuovoUser} variant="success">
          <Alert.Heading>
            Registrazione del nuvo Utente Avvenuta con Successo!
          </Alert.Heading>
        </Alert>
        <Alert show={AlertLoginUser} variant="success">
          <Alert.Heading>
            LogIn Avvenuto con Successo!
          </Alert.Heading>
        </Alert>
        <h1>Registrati oppure Loggati</h1>
        <Form.Group className="mb-3 input" controlId="formBasicEmail">
          <Form.Label className="formLabel">Indirizzo Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            onChange={(e) => setEmail(e.target.value)}
            value={email}
          />
        </Form.Group>

        <Form.Group className="mb-3 input" controlId="formBasicPassword">
          <Form.Label className="formLabel">Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Password"
            onChange={(e) => setPass(e.target.value)}
            value={pass}
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Iscriviti
        </Button>
      </Form>
    </div>
  );
}
export default Registrazione;
