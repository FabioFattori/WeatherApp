import React, { useState, useEffect } from "react";
import Card from "react-bootstrap/Card";
import "../CSS/Home.css";
import Alert from "react-bootstrap/Alert";
import Axios from "axios";
import { doc, getDoc } from "firebase/firestore";
import { DB } from "../utils/firebase";
import { useHistory } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";
import Button from "react-bootstrap/Button";

function Home() {
  const History = useHistory();

  const [LocalitàSalvate, setLocalitàSalvate] = useState([]);

  function getCittaPrefe() {
    const docRef = doc(
      DB,
      "Users",
      localStorage.getItem("UserID").split("|")[1]
    );

    var cities;
    getDoc(docRef).then((response) => {
      cities =
        response._document.data.value.mapValue.fields.Preferiti.arrayValue
          .values;
      if (cities === undefined ) {
        return;
      } else {
        var EndVariable = []; //questa variabile mi serve per utilizzare il metodo setLocalitàSalvate per far ricaricare la pagina e quindi far vedere le città salvate nei preferiti

        cities.forEach((città) => {
          return Axios.get(
            "https://api.openweathermap.org/data/2.5/weather?q=" +
              città.stringValue +
              "&units=metric&lang=it&appid=0ec33f7b8a72aae2d8c7618d98f42a22"
          ).then((response) => {
            var CittaCercata = {
              NomeCitta: "",
              temp: "",
              feels_like: "",
              umidità: "",
              descrizione: "",
            };

            CittaCercata.NomeCitta = città.stringValue.toUpperCase();
            CittaCercata.temp = response.data.main.temp;
            CittaCercata.feels_like = response.data.main.feels_like;
            CittaCercata.umidità = response.data.main.humidity;
            CittaCercata.descrizione =
              response.data.weather[0].description.toUpperCase();
            EndVariable.push(CittaCercata);
          });
        });
        
        setLocalitàSalvate("loading");
        setTimeout(() => setLocalitàSalvate(EndVariable.sort()), 500);
      }
    });
  }

  function GraficaLocalita() {
    if (LocalitàSalvate === "loading") {
      return (
        <Button variant="dark" disabled>
          <Spinner
            as="span"
            animation="border"
            size="xl"
            role="status"
            aria-hidden="true"
          />
        </Button>
      );
    } else if (LocalitàSalvate.length === 0) {
      return (
        <Alert key="dark" variant="dark">
          Non hai nessuna città nei preferiti :(
        </Alert>
      );
    } else if (Array.isArray(LocalitàSalvate) === false) {
      return (
        <Card style={{ width: "18rem" }}>
          <Card.Body>
            <Card.Title>{LocalitàSalvate.NomeCitta}</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">
              {LocalitàSalvate.descrizione}
            </Card.Subtitle>
            <Card.Text>
              Temperatura: {LocalitàSalvate.temp} °C <br />
              Percepita: {LocalitàSalvate.feels_like} °C <br />
              Umidità: {LocalitàSalvate.umidità}%
            </Card.Text>
          </Card.Body>
        </Card>
      );
    } else {
      return LocalitàSalvate.map((località) => {
        return (
          <Card className="LocandinaLocalità" key={località.NomeCitta}>
            <Card.Body>
              <Card.Title>{località.NomeCitta}</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                {località.descrizione}
              </Card.Subtitle>
              <Card.Text>
                Temperatura: {località.temp} °C <br />
                Percepita: {località.feels_like} °C <br />
                Umidità: {località.umidità}%
              </Card.Text>
            </Card.Body>
          </Card>
        );
      });
    }
  }

  useEffect(() => {
    if (localStorage.getItem("UserID") === null) {
      History.push("/Registrazione");
    } else {
      getCittaPrefe();
    }
  }, []);

  return (
    <div className="HomeBody">
      <h1 className="Title">Le Tue Città Preferite:</h1>

      <div className="CittàSalvate">{GraficaLocalita()}</div>
    </div>
  );
}

export default Home;
