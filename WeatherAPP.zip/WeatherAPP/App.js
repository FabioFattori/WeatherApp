import React from 'react';
import {Provider, DefaultTheme} from 'react-native-paper';
import NavBar from './Componenti/NavBar';
import {NavigationContainer} from '@react-navigation/native';
import Home from './Componenti/Home';
import Search from './Componenti/Search';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

function App() {
  const Theme = {
    ...DefaultTheme,
    dark: true,
    mode: 'adaptive',
    colors: {
      ...DefaultTheme.colors,
      primary: '#000000',
      accent: '#ffffff',
    },
  };

  const Stack = createNativeStackNavigator();

  return (
    <NavigationContainer>
      <Provider theme={Theme}>
        <NavBar />
        <Stack.Navigator>
          <Stack.Screen name="Home" component={Home} />
          <Stack.Screen name="Search" component={Search} />
        </Stack.Navigator>
      </Provider>
    </NavigationContainer>
  );
}

export default App;
