import{initializeApp}from'firebase/app'
  import{getFirestore}from'firebase/firestore'

const firebaseConfig = {
  apiKey: "AIzaSyCSbpLYK17rCQ5p4LhMPIo0kb7bRp2x-YU",
  authDomain: "myweather-7c83e.firebaseapp.com",
  projectId: "myweather-7c83e",
  storageBucket: "myweather-7c83e.appspot.com",
  messagingSenderId: "157491988909",
  appId: "1:157491988909:web:843a6ccd3f18f00ffb3924",
  databaseURL: "http://myweather-7c83e.firebaseio.com",
};

// Import the functions you need from the SDKs you need

  // Your web app's Firebase configuration
 
  // Initialize Firebase
  const app=initializeApp(firebaseConfig)

  export const DB=getFirestore(app)