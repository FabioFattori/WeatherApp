import React from 'react';
import { Appbar } from 'react-native-paper';

function NavBar() {
  const _goBack = () => console.log('Went back');

  
  return (
    <Appbar.Header >
      <Appbar.BackAction onPress={_goBack} />
      <Appbar.Content title="Meteo" />
      <Appbar.Content title="Home" />
      <Appbar.Content title="Search" />
      
    </Appbar.Header>
  );
}

export default NavBar;
