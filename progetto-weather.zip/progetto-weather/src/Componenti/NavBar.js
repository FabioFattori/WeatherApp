import React,{useState,useEffect} from "react";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import { useHistory } from "react-router-dom";
import "../CSS/NavBar.css";

function NavBar() {
  const History = useHistory();


  React.useEffect(() => {
    function handleResize() {
      if(window.innerWidth>650){
        setExpand(true);
      }else{
        setExpand(false);
      }
    
}

    window.addEventListener('resize', handleResize)
  })
  

  const KnowWhatToShow = () => {
    if (
     
      localStorage.getItem("UserID") === null
    ) {
      return (
        <Nav.Link onClick={() => History.push("/Registrazione")}>
          Registrati
        </Nav.Link>
      );
    } else {
      return (
        <div className="Nav">
          <Nav.Link>{localStorage.getItem("UserID").split("|")[0]}</Nav.Link>
          <Nav.Link
            onClick={() => {
              localStorage.clear();
              window.location.reload();
            }}
          >
            logOut
          </Nav.Link>
        </div>
      );
    }
  };

  return (
    
    <Navbar bg="dark" variant="dark" sticky="top" className="Navbar" >
      <Container>
        <Navbar.Brand>Meteo</Navbar.Brand>
        <Nav className="me-auto">
          <Nav.Link onClick={() => History.push("/")}>Home</Nav.Link>
          <Nav.Link onClick={() => History.push("/Search")}>Ricerca</Nav.Link>
          {KnowWhatToShow()}
        </Nav>
      </Container>
    </Navbar>
  );
}

export default NavBar;
