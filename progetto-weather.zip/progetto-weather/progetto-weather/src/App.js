import "./App.css";
import NavBar from "./Componenti/NavBar";
import Home from "./Componenti/Home";
import Search from "./Componenti/Search";
import Reg from "./Componenti/registrazione";
import { BrowserRouter, Switch, Route } from "react-router-dom";

function App() {
  

  return (
    <BrowserRouter>
      <div className="App">
        <NavBar />
        <Switch>
          <Route path="/Search">
            <Search />
          </Route>
          <Route path="/Registrazione">
            <Reg />
          </Route>
          <Route path="/">
            <Home />
          </Route>
          <Route path="*">
            <div>
              <h1>ERRORE 404</h1>
            </div>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
