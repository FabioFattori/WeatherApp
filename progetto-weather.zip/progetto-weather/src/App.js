import "./App.css";
import NavBar from "./Componenti/NavBar";
import Home from "./Componenti/Home";
import Search from "./Componenti/Search";
import { BrowserRouter, Switch, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        
      <NavBar />
        <Switch>
          <Route path="/Search"><Search /></Route>
          <Route path="/"><Home /></Route>
          <Route path="*">
            <div>
              <h1>ERRORE 404</h1>
              <h3>Hai la 104</h3>
            </div>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
