
import { View, Image, Button } from "react-native";
import Search from '../Componenti/Search'

import React, { Component } from 'react'

export default class SearchPage extends Component {
  render() {
    const navigation=this.props.navigation
    return (
        <View>
             <Search nav={navigation}/> 
        </View>
    )
  }
}
