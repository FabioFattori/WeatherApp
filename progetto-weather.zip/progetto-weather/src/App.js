import "./App.css";
import Home from "./Componenti/Home"
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route path="/">
            <Home />
          </Route>
          <Route path="*">
            <div>
              <h1>ERRORE 404</h1>
              <h3>Hai la 104</h3>
            </div>
          </Route>
          
        </Switch>
      </Router>
    </div>
  );
}

export default App;
