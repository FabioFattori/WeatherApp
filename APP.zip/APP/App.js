import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import HomePage from './Schermate/HomePage';
import SearchPage from './Schermate/SearchPage';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {ImageBackground, View, Text, StyleSheet} from 'react-native';

function App() {
  const styles = StyleSheet.create({
    container: {
      flex: 0.4,
    },
    image: {
      flex: 1,
      justifyContent: 'center',
    },
    text: {
      color: 'white',
      fontSize: 42,
      lineHeight: 84,
      fontWeight: 'bold',
      textAlign: 'center',
      backgroundColor:'hsla(0,0%,0%,0.3)',
    },
  });
  const Stack = createNativeStackNavigator();
  return (
    <View style={styles.container}>
      <ImageBackground
        source={require('./img/sfondo.jpg')}
        resizeMode="cover"
        style={styles.image}>
        <Text style={styles.text}>METEO</Text>
      </ImageBackground>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home/Preferiti">
          <Stack.Screen name="Home/Preferiti" component={HomePage} />
          <Stack.Screen name="Search" component={SearchPage} />
        </Stack.Navigator>
      </NavigationContainer>
    </View>
  );
}

export default App;
