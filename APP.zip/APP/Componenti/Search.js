import React from 'react';
import {Text, View, Button, StyleSheet} from 'react-native';
import {Searchbar} from 'react-native-paper';
import Axios from 'axios';

export default class Search extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      navi: '',


      CittaCercata: {
        NomeCitta: '',
        temp: '',
        feels_like: '',
        umidità: '',
        descrizione: '',
      },

      DatiCittà : null,
    };
  }

  render() {
    const styles = StyleSheet.create({
      container: {
        marginLeft: '2%',
        marginRight: '2%',
        marginTop: '5%',
        justifyContent: 'space-between',
        fontWeight: '100px',
        fontFamily: 'Kuro',
        color: 'rgb(255, 255, 255)',
        /* regole del bordo */
        borderRadius: '35px',
        borderWidth: '3px',
        paddingLeft: '3%',
        paddingRight: '3%',
        paddingTop: '3%',
        paddingBottom: '3%',
      },
    });

    this.state.navi = this.props.nav;
    

    //search bar method

    const Search = () => {
      const [searchQuery, setSearchQuery] = React.useState('');

      const onChangeSearch = query => {
        
        console.log(query)
        Axios.get(
          'https://api.openweathermap.org/data/2.5/weather?q=' +
            query +
            '&units=metric&lang=it&appid=5d10ca667917b3430cb194283e34f3c0',
        ).then(response => {
          this.state.CittaCercata.NomeCitta = query.toUpperCase();
          this.state.CittaCercata.temp = response.data.main.temp;
          this.state.CittaCercata.feels_like = response.data.main.feels_like;
          this.state.CittaCercata.umidità = response.data.main.humidity;
          this.state.CittaCercata.descrizione =
            response.data.weather[0].description.toUpperCase();

            var urlIMG =
      "http://openweathermap.org/img/w/" + WeatherData.weather[0].icon + ".png";

          this.state.DatiCittà = 
             <View style={styles.container}>
              <Text>ao</Text>
              {/* <View className="CoppiaDivalori">
                <Text>Temperatura Effettiva:</Text>
                <Text>{this.state.CittaCercata.temp} °C</Text>
              </View>
              <View className="CoppiaDivalori">
                <Text>Percepita:</Text>
                <Text>{this.state.CittaCercata.feels_like} °C</Text>
              </View>
              <View className="CoppiaDivalori">
                <Text>Umidità:</Text>
                <Text>{this.state.CittaCercata.umidità}%</Text>
              </View>
              <View className="CoppiaDivalori">
                <Text>
                  {this.state.CittaCercata.descrizione}
                 <img src={urlIMG} alt="img" /> 
                </Text>
              </View> */}
            </View>;
          
        });
      };

      return <Searchbar placeholder="Città" C onIconPress={onChangeSearch} />;
    };

    //cose che renderizzo
    return (
      <View>
        <Search />

        {this.state.DatiCittà}
      </View>
    );
  }
}
