import React from 'react';
import {View, Text} from 'react-native';
import {Button} from 'react-native-paper';

function Home({navigation}) {
  return (
    <View className="Home">
      <Text>Home</Text>
      <Button
        icon="camera"
        mode="contained"
        onPress={() => navigation.navigate('Search')}>
        Press me
      </Button>
    </View>
  );
}

export default Home;
